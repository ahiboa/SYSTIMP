<html>
<body>

<?php
session_start();

?>

<p><p>
MENU
<p>
<a href="addcustomer.php">Create Customer Account</a> <br><br>
<a href="addadmin.php">Create Admin Account</a> <br><br>
<a href="addemployee.php">Create Employee Account</a><br><br>
<a href="addagency.php">Add Agency</a><br><br>
<a href="menu.php">Return</a>

</body>
</html>