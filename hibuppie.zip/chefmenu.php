<html>
<body>

<?php
session_start();

?>

<p><p>
MENU
EVENTS TAB: <br>
<a href="eventslist.php">View Events</a> <br> <br>
MENU TAB: <br>
<a href="addmenu.php">Packages</a> <br> <br>
<a href="adjustmenu.php">Adjust Menu Item</a> <br> <br>
<a href="addrecipe.php">Create Recipe</a> <br> <br>
<a href="viewrecipe.php">View Recipes</a> <br> <br>
<a href="logout.php"> Logout </a> 


</body>
</html>