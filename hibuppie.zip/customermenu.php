<html>
<body>

<?php
session_start();

?>

<p><p>
MENU
<p>
ORDERS: <br>
<a href="eventsched.php">Place Event Reservation</a> <br> <br>
<a href="customerviewpackage.php">View Package Menu</a> <br> <br>
EVENTS: <br>
<a href="customerschedule.php">View Reserved Events</a> <br> <br>
VIEW HISTORY: <br>
<a href="customerhistory.php">View Order History</a> <br> <br>
PAYMENTS: <br>
<a href="paycredit.php">Pay via Credit</a> <br> <br>
OTHERS: <br>
<a href="feedback.php">Send Feedback</a> <br> <br>
<a href="logout.php"> Logout </a> 


</body>
</html>