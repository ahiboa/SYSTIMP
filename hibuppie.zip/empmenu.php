<html>
<body>

<?php
session_start();

?>

<p><p>
MENU
<p>
<a href="viewsched.php">View Schedule</a> <br>

<a href="logout.php"> Logout </a> 


</body>
</html>