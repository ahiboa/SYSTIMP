<html>   
	<body>
		<h2 align="center">Thank you for sending us your feedback</h2>
		<a href = "customermenu.php"><button>Back To Main Menu</button></a>
	</body>
</html>