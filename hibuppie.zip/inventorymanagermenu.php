<?php
session_start();
?>

<html>
<body>

<p>
EVENTS: <br>
<a href="eventslist.php">View Events</a><br><br>
INVENTORY MANAGEMENT:
<p>
<a href="deployedinventory.php">Record Inventory Deployments</a><br><br>
<a href="deployedview.php">View Deployed Items</a><br><br>
<a href="returninventory.php">Record Inventory Returns</a><br><br>
<a href="updateinventory.php">Update Inventory</a><br><br>
<a href="addinventory.php">Add New Inventory Item</a><br><br>
<a href="deployedinventory.php">View Deployed Inventory</a><br><br>
<a href="currentinventory.php">View Current Inventory</a><br><br>
<a href="damagedinventory.php">View Damaged Inventory</a> <br><br>
<a href="lostinventory.php">View Lost Inventory</a><br><br>
<a href="recordlostdamaged.php">Record Lost/Damaged Inventory</a><br><br>

<a href="logout.php">Logout</a><br><br>