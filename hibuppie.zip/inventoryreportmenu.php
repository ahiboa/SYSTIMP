<html>
<body>

<p><p>
INVENTORY REPORT MENU
<p>
<a href="currentinventory.php">View Current Inventory</a><br><br>
<a href="damagedinventory.php">View Damaged Inventory</a> <br><br>
<a href="lostinventory.php">View Lost Inventory</a><br><br>


<a href="reportmenu.php">Return</a><br><br>