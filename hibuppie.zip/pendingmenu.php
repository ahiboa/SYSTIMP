<html>
<body>
<a href="receivecash.php">Verify Cash Payments</a> <br><br>
<a href="receivepayment.php">Verify Credit Payments</a> <br><br>
<a href="menu.php">Return</a> <br><br>