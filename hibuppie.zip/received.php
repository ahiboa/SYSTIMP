<html>   
	<body>
		<h2 align="center">Payment has been received. Thank you!</h2>
		<a href = "customermenu.php"><button>Back To Main Menu</button></a>
	</body>
</html>