<html>
<body>

<p><p>
REPORT MENU
<p>
<a href="salesreportmenu.php">View Sales Report</a><br><br>
<a href="inventoryreportmenu.php">View Inventory Report</a><br><br>

<a href="menu.php">Return</a><br><br>