<html>
<body>

<p><p>
SALES REPORT MENU
<p>
<a href="selectreport.php">Select Specific Report Date for Sales</a><br><br>
<a href="dailyreport.php">View Daily Sales Report</a> <br><br>
<a href="monthlyreport.php">View Monthly Sales Report</a><br><br>

<a href="reportmenu.php">Return</a><br><br>